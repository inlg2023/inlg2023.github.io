# bash dump_text_emb_mbart.sh mspm4_xgiga en_XX /mnt/bd/lab-wxz/clt/cc100/en.first1w.txt cc100_first1w_en_layer9 false
# bash dump_text_emb_mbart.sh mspm4_xgiga zh_CN /mnt/bd/lab-wxz/clt/cc100/zh.first1w.txt cc100_first1w_zh_layer9 true
# bash dump_text_emb_mbart.sh mspm4_xgiga fr_XX /mnt/bd/lab-wxz/clt/cc100/fr.first1w.txt cc100_first1w_fr_layer9 true

bash dump_text_emb_mbart.sh mspm4_xgiga en_XX /mnt/bd/lab-wxz/clt/wiki40b/en.first100k.txt wiki40b_first100k_en_layer9 true
bash dump_text_emb_mbart.sh mspm4_xgiga zh_CN /mnt/bd/lab-wxz/clt/wiki40b/zh.first100k.txt wiki40b_first100k_zh_layer9 true
bash dump_text_emb_mbart.sh mspm4_xgiga fr_XX /mnt/bd/lab-wxz/clt/wiki40b/fr.first100k.txt wiki40b_first100k_fr_layer9 true

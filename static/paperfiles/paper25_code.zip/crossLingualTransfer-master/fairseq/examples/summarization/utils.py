import json

def loadAdapterConfig(filepath):
    return json.load(
        open(filepath, "r")
    )

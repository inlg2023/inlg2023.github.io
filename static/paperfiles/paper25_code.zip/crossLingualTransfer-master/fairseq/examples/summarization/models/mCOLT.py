from fairseq.models import register_model_architecture


@register_model_architecture('transformer', 'transformer_big_t2t_12e12d')
def transformer_big_t2t_12e12d(args):
    args.dropout = getattr(args, 'dropout', 0.1)
    args.encoder_layers = getattr(args, 'encoder_layers', 12)
    args.decoder_layers = getattr(args, 'decoder_layers', 12)
    from fairseq.models.transformer import transformer_wmt_en_de_big_t2t
    transformer_wmt_en_de_big_t2t(args)

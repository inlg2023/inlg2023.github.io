import sys
sys.path.append('.')

from .linear import LinearClassifier
#!/usr/bin/env bash

# bash finetune_multi_zero.sh train EnFr mspm4_mlsum mbart_zero

MODE="$1"
LG="$2"
DATAVER="$3"
NAME="$4"

argslist=""
for (( i = 5; i <= $# ; i++ ))
  do
    j=${!i}
    argslist="${argslist} $j "
  done
echo $argslist >&2

cd "$(dirname $0)" || return

echo "Install fairseq" >&2

sudo mkdir -p /usr/lib/python3.7/site-packages/
sudo pip3 install -e fairseq
pip3 install -r requirements.txt -i http://pypi.byted.org/simple/ --trusted-host=pypi.byted.org

# sudo apt-get update
# sudo apt-get install libxml-perl libxml-dom-perl

export PYROUGE_HOME_DIR=$(pwd)/RELEASE-1.5.5
export PYROUGE_TEMP_PATH=/opt/tiger

pyrouge_set_rouge_path $PYROUGE_HOME_DIR
chmod +x $PYROUGE_HOME_DIR/ROUGE-1.5.5.pl

prefix=hdfs://haruna/home/byte_arnold_lq_mlnlc/user/wangdanqing.122
wxz_prefix=hdfs://haruna/home/byte_arnold_hl_mlnlc/user/wuxianze.0

# dataset_path=${prefix}/Datasets/multilingual/data-bin/${DATAVER}/${LG}
dataset_path=${wxz_prefix}/Datasets/multilingual/data-bin/${DATAVER}/${LG}
tensorboard_logdir=${wxz_prefix}/Workspace/Multilingual/mlsum_${LG}/logs/${NAME}_zero
checkpoint_path=${wxz_prefix}/Workspace/Multilingual/mlsum_${LG}/checkpoints/${NAME}_zero
pretrained_path=${prefix}/Workshop/MultiLingual/pretrained

# change checkpoint path
hdfs dfs -mkdir -p $tensorboard_logdir
hdfs dfs -mkdir -p $checkpoint_path

local_root=~/${NAME}_${LG}_zero
resource_root=${local_root}/resource
output_path=${local_root}/output
model_path=${local_root}/model
mkdir -p ${resource_root}
mkdir -p ${output_path}
mkdir -p ${model_path}

local_dataset_path=${resource_root}/dataset
mkdir -p ${local_dataset_path}
hadoop fs -copyToLocal ${dataset_path}/* ${local_dataset_path}
echo "Download resource from ${dataset_path} to ${local_dataset_path}" >&2

local_tensorboard_path=${output_path}/tensorboard_logdir
#hadoop fs -copyToLocal ${tensorboard_logdir} ${local_tensorboard_path}
mkdir -p ${local_tensorboard_path}

local_checkpoint_path=${output_path}/checkpoint_path
mkdir -p ${local_checkpoint_path}
# hadoop fs -copyToLocal ${checkpoint_path}/checkpoint_last.pt ${local_checkpoint_path}
# echo "Load checkpoints from ${checkpoint_path}/checkpoint_last.pt to ${local_checkpoint_path}" >&2

local_pretrained_path=${model_path}/mbart.cc25
if [ ! -d ${local_pretrained_path} ]; then
  echo "Load pretrained model from ${pretrained_path}/mbart.CC25.tar.gz to ${local_pretrained_path}" >&2
  hadoop fs -copyToLocal ${pretrained_path}/mbart.CC25.tar.gz ${model_path}
  tar -xvzf ${model_path}/mbart.CC25.tar.gz -C ${model_path}
else
  echo "Pretrained model in ${local_pretrained_path}" >&2
fi

echo "Finish download files" >&2

langs=ar_AR,cs_CZ,de_DE,en_XX,es_XX,et_EE,fi_FI,fr_XX,gu_IN,hi_IN,it_IT,ja_XX,kk_KZ,ko_KR,lt_LT,lv_LV,my_MM,ne_NP,nl_XX,ro_RO,ru_RU,si_LK,tr_TR,vi_VN,zh_CN

echo "Training..."

python3 fairseq/train.py ${local_dataset_path} --ddp-backend=no_c10d \
--save-dir ${local_checkpoint_path} \
--tensorboard-logdir ${local_tensorboard_path} \
--restore-file ${local_pretrained_path}/model.pt \
--task summarization_from_pretrained_mbart_mspm4 \
--arch mbart_large \
--source-lang doc --target-lang sum \
--langs $langs \
--dataset-impl mmap \
--truncate-source \
--encoder-normalize-before --decoder-normalize-before \
--layernorm-embedding \
--criterion label_smoothed_cross_entropy --label-smoothing 0.2 \
--reset-optimizer --reset-dataloader --reset-meters --reset-lr-scheduler \
--required-batch-size-multiple 1 \
--dropout 0.1 --attention-dropout 0.1 \
--weight-decay 0.01 --optimizer adam --adam-betas "(0.9, 0.999)" --adam-eps 1e-08 \
--lr 3e-5 --min-lr -1 \
--lr-scheduler polynomial_decay \
--clip-norm 0.1 \
--update-freq 4 \
--max-update 8 \
--skip-invalid-size-inputs-valid-test \
--find-unused-parameters \
--num-workers 100 \
--fp16 \
--max-tokens 2048 \
--total-num-update 200000 --warmup-updates 2500 \
--log-interval 200 \
--log-format simple \
--keep-best-checkpoints 3 \
--no-epoch-checkpoints \
--patience 2 \
--user-dir examples/summarization
# $argslist

echo "Generating..."

hadoop fs -copyToLocal ${checkpoint_path}/checkpoint_best.pt ${local_checkpoint_path}
echo "Load checkpoints from ${checkpoint_path}/checkpoint_best.pt to ${local_checkpoint_path}" >&2

suffix=$(echo "$argslist" | sed -e "s/-//g"  -e "s/  */_/g")

python3 fairseq/generate.py ${local_dataset_path}  \
--path ${local_checkpoint_path}/checkpoint_last.pt \
--task summarization_from_pretrained_mbart_mspm4 \
--gen-subset test \
--source-lang doc --target-lang sum \
--langs $langs \
--remove-bpe 'sentencepiece'  \
--min-len 30 \
--max-len-b 50 \
--lenpen 0.6 \
--no-repeat-ngram-size 3 \
--truncate-source \
--user-dir examples/summarization \
$argslist \
> ${local_tensorboard_path}/"output$suffix"

cat ${local_tensorboard_path}/"output$suffix" | grep -P "^H" | sort -V |cut -f 3- | sed -e  "s/\[[a-z]\{2\}_[A-Z]\{2\}\]//g" > ${local_tensorboard_path}/"test$suffix.hypo"

echo "Load ground truth file from ${wxz_prefix}/Datasets/multilingual/mlsum/${LG}/test.${LG}.sum"
hadoop fs -get ${wxz_prefix}/Datasets/multilingual/mlsum/${LG}/test.${LG}.sum ${local_dataset_path}

python3 utils/calRouge.py \
-c ${local_tensorboard_path}/"test$suffix.hypo" \
-r ${local_dataset_path}/test.${LG}.sum \
-l ${LG} -d "<q>"

echo "Put ${local_tensorboard_path} to ${tensorboard_logdir}" >&2
hadoop fs -put -f ${local_tensorboard_path}/* ${tensorboard_logdir}/
sleep 600

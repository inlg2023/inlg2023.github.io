from fitbert.fitb import *
from fitbert.version import __version__

name = "fitbert"

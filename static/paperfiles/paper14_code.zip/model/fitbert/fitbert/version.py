# CHANGES HERE HAVE NO EFFECT: ../VERSION is the source of truth
__version__ = "0.4.0"
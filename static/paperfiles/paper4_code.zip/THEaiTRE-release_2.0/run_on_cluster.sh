#!/bin/bash

#$ -q gpu-'*'.q
#$ -l gpu=1,gpu_ram=16G,hostname='tdll*|dll1|dll8'
#$ -V 
#$ -cwd
#$ -b y
#$ -j y
#$ -N "URUserver"

while true;do
    ./start_server.sh
    sleep 1
done

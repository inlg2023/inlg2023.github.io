#!/bin/bash

echo "Content-Type: text/css"
echo ""

cat ../staticsource/FILE

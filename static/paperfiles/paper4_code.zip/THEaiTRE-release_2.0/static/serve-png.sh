#!/bin/bash

echo "Content-Type: image/png"
echo ""

cat ../staticsource/FILE

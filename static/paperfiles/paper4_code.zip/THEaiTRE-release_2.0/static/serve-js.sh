#!/bin/bash

echo "Content-Type: text/javascript"
echo ""

cat ../staticsource/FILE

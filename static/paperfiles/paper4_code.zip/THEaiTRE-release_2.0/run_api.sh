python api.py > api.log 2> api.elog
